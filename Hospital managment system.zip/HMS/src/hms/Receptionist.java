/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hms;

/**
 *
 * @author Hp
 */
public class Receptionist extends User{
   
    public Receptionist(String username, String password) {
        super("Receptionist", username, password);
    }
    
}
